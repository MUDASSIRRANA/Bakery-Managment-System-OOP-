import java.io.*;
import java.util.ArrayList;

public class Order implements Serializable {
    private Product[] cutomerCart;
    private int productCount;
    private int totalBill;
    private Customer customer;

    Order(Customer c) {
        this.cutomerCart = new Product[10];
        this.productCount = 0;
        this.totalBill = 0;
        this.customer = c;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Product[] getAllProducts() {
        return cutomerCart;
    }

    public int getProductCount() {
        return productCount;
    }

    public int getSpentMoney() {
        return totalBill;
    }

    public void setProductCount(int productCount) {
        this.productCount = productCount;
    }

    public void setSpentMoney(int earnedMoney) {
        this.totalBill = earnedMoney;
    }

    public void addProduct(Product p) {
        if (this.productCount >= this.cutomerCart.length) {
            return;
        }
        for (int i = 0; i < this.cutomerCart.length; i++) {
            if (this.cutomerCart[i] == null) {
                this.cutomerCart[i] = p;
                productCount++;
                this.setSpentMoney(this.getSpentMoney()+p.getPrice());
                break;
            }
        }
    }

    public void deleteProduct(Product p) {
        if (productCount == 0) {
            System.out.println("The Menu is empty. Please add items to the Menu first.");
        }

        for (int i = 0; i < cutomerCart.length; i++) {
            if (cutomerCart[i].isEqual(p)) {
                for (int j = i; j < cutomerCart.length - 1; j++) {
                    cutomerCart[j] = cutomerCart[j + 1];
                }
                this.setSpentMoney(this.getSpentMoney()-p.getPrice());
                return;
            }
        }
    }

    public void display(){
        System.out.println(this.customer.toString()+"\n----HAS ITEMS----\n");
        for (int i = 0; i< cutomerCart.length; i++) {
            if (this.cutomerCart[i] != null) {
                if (cutomerCart[i] instanceof BakeryItem) {
                    BakeryItem temp = (BakeryItem) cutomerCart[i];
                    temp.display();
                } else if (cutomerCart[i] instanceof OtherItems) {
                    OtherItems temp1 = (OtherItems) cutomerCart[i];
                    temp1.display();
                }
            }
        }
    }
    public static void writeServeToFile(Order p){
        try
        {
            File f = new File("ServeData.ser");

            ObjectOutputStream oos;
            if(f.exists())
                oos = new MyObjectOutputStream(new FileOutputStream(f,true));
            else{
                oos = new ObjectOutputStream(new FileOutputStream(f));
            }

            oos.writeObject(p);
            oos.close();
        }
        catch(IOException ex)
        {
            System.out.println("File not found in writer");
        }
    }
    public static ArrayList<Order> readFromAppointmentFile(){
        ArrayList<Order>list = new ArrayList<Order>();
        ObjectInputStream  ois;
        try
        {
            ois = new ObjectInputStream(new FileInputStream("ServeData.ser"));
            while(true)
            {
                Order e = (Order) ois.readObject();
                list.add(e);
            }

        }
        catch(ClassNotFoundException e1)
        {
            System.out.println("ClassNotFoundException");
        }
        catch(EOFException e2)
        {
            return list;
        }
        catch(IOException ex)
        {
            System.out.println("File not found in reader");
        }
        return list;
    }
    public static void deleteProductHavingEXPDate(PDate d){
        ArrayList<Order>list = Order.readFromAppointmentFile();
        for (int i = 0 ;i<list.size();i++){
            for (int j = 0;j<list.get(i).getAllProducts().length;j++) {
                if (list.get(i).getAllProducts()[j] != null) {
                    if (list.get(i).getAllProducts()[j] instanceof BakeryItem) {
                        BakeryItem temp_1 = (BakeryItem) list.get(i).getAllProducts()[j];
                        if (temp_1.getEXPDate().isEqual(d)) {
                            list.remove(i);
                            break;
                        }
                    } else if (list.get(i).getAllProducts()[j] instanceof OtherItems) {
                        OtherItems temp_2 = (OtherItems) list.get(i).getAllProducts()[j];
                        if (temp_2.getEXPDate().isEqual(d)) {
                            list.remove(i);
                            break;
                        }
                    }
                }
            }
        }
        try {
            File f = new File("ServeData.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i< list.size(); i++){
                oos.writeObject(list.get(i));
            }
        }
        catch (IOException e){
            System.out.println("File not found in writer");
        }
    }
    public static void addCustomerItem(Customer c,Product p) {
        ArrayList<Order> list = Order.readFromAppointmentFile();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getCustomer().isEqual(c)) {
                if (list.get(i).productCount >=list.get(i).getAllProducts().length) {
                    System.out.println("CART IS EMPTY");
                    return;
                }
                for (int j = 0; j < list.get(i).getAllProducts().length; j++) {
                    if (list.get(i).cutomerCart[j] == null) {
                        list.get(i).cutomerCart[j] = p;
                        list.get(i).setProductCount(list.get(i).getProductCount() + 1);
                        list.get(i).setSpentMoney(list.get(i).getSpentMoney() + list.get(i).cutomerCart[j].getPrice());
                        break;
                    }
                }
            }
        }
        try {
            File f = new File("ServeData.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i< list.size(); i++){
                oos.writeObject(list.get(i));
            }
        }
        catch (IOException e){
            System.out.println("File not found in writer");
        }
    }
    public static void DeleteCustomerItem(Customer c,Product p) {
        ArrayList<Order> list = Order.readFromAppointmentFile();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getCustomer().isEqual(c)) {
                if (list.get(i).productCount == 0) {
                    System.out.println("CART IS EMPTY ");
                    return;
                }
                for (int j = 0; j < list.get(i).getAllProducts().length; j++) {
                    if (list.get(i).cutomerCart[j].isEqual(p)) {
                        for (int k = j; k < list.get(i).cutomerCart.length - 1; k++) {
                            list.get(i).cutomerCart[k] = list.get(i).cutomerCart[k + 1];
                        }
                        list.get(i).setProductCount(list.get(i).getProductCount() - 1);
                        list.get(i).setSpentMoney(list.get(i).getSpentMoney() - list.get(i).cutomerCart[j].getPrice());
                        break;
                    }
                }
            }
        }
        try {
            File f = new File("ServeData.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
    public static int giveTotalBill(Customer c){
        ArrayList<Order> list = Order.readFromAppointmentFile();
        for (int i = 0; i<list.size(); i++){
            if (list.get(i).getCustomer().isEqual(c)){
                return list.get(i).getSpentMoney();
            }
        }
        return 0;
    }
    public static void checkFor_15_Discount(Customer c){
        ArrayList<Order> list = Order.readFromAppointmentFile();
        for (int i = 0; i<list.size(); i++){
            if (list.get(i).getCustomer().isEqual(c)){
                if (list.get(i).getSpentMoney() >= 3000){
                    list.get(i).setSpentMoney(list.get(i).getSpentMoney() - ((list.get(i).getSpentMoney() *15)/100));
                    System.out.println("Discounted");
                }
            }
        }
        try {
            File f = new File("ServeData.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
}







