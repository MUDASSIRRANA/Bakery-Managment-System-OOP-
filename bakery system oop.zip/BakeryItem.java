import java.io.*;
import java.util.ArrayList;
import java.util.Date;

public class BakeryItem extends Product implements Serializable,Equal {
    private String type;

    BakeryItem(PDate m, PDate e, String n, int p,String t) {
        super(m, e, n, p);
        this.type = t;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public String toString(){
        return (super.toString()+"\nType : "+this.getType());
    }
    public void display(){
        System.out.println(this.toString());
    }
    @Override
    public boolean isEqual(Object o){
        BakeryItem temp = (BakeryItem) o;
        return (super.isEqual(o) && this.type.equals(temp.getType()));
    }
    public static void writeBakeryItemsToFile(BakeryItem p){
        try
        {
            File f = new File("BakeryItems.ser");

            ObjectOutputStream oos;
            if(f.exists())
                oos = new MyObjectOutputStream(new FileOutputStream(f,true));
            else{
                oos = new ObjectOutputStream(new FileOutputStream(f));
            }

            oos.writeObject(p);
            oos.close();
        }
        catch(IOException ex)
        {
            System.out.println("File not found in writer");
        }
    }
    public static ArrayList<BakeryItem> readFromBakeryItemsFile(){
        ArrayList<BakeryItem>list = new ArrayList<BakeryItem>();
        ObjectInputStream  ois;
        try
        {
            ois = new ObjectInputStream(new FileInputStream("BakeryItems.ser"));
            while(true)
            {
                BakeryItem e = (BakeryItem) ois.readObject();
                list.add(e);
            }

        }
        catch(ClassNotFoundException e1)
        {
            System.out.println("ClassNotFoundException");
        }
        catch(EOFException e2)
        {
            return list;
        }
        catch(IOException ex)
        {
            System.out.println("File not found in reader");
        }
        return list;
    }
    public static void deleteExpireItems(int year) {
        ArrayList<BakeryItem> list = BakeryItem.readFromBakeryItemsFile();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getEXPDate().getYear() == year){
                list.remove(i);
                break;
            }
        }
        try {
            File f = new File("BakeryItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
    public static void updatePriceOfItem(String name,int price){
        ArrayList<BakeryItem>list = BakeryItem.readFromBakeryItemsFile();
        for (int i = 0; i< list.size() ; i++){
            if (list.get(i).getName().equals(name)){
                list.get(i).setPrice(price);
                break;
            }
        }
        try {
            File f = new File("BakeryItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }



}

