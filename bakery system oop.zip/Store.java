import java.io.*;
import java.util.ArrayList;

public class Store implements Serializable {
    private Product[] allProducts;
    private int allProductsCount;

    Store(){
        this.allProducts = new Product[100];
        this.allProductsCount = 0;
    }

    public Product[] getAllProducts() {
        return allProducts;
    }

    public void setAllProducts(Product[] allProducts) {
        this.allProducts = allProducts;
    }

    public int getAllProductsCount() {
        return allProductsCount;
    }

    public void setAllProductsCount(int allProductsCount) {
        this.allProductsCount = allProductsCount;
    }

    public void display(){
        for (int i = 0; i< allProducts.length; i++) {
            if (this.allProducts[i] != null) {
                if (allProducts[i] instanceof BakeryItem) {
                    BakeryItem temp = (BakeryItem) allProducts[i];
                    temp.display();
                } else if (allProducts[i] instanceof OtherItems) {
                    OtherItems temp1 = (OtherItems) allProducts[i];
                    temp1.display();
                }
            }
        }
    }
    public static void writeTOStoreItemFile(Store p){
        try
        {
            File f = new File("StoreItems.ser");

            ObjectOutputStream oos;
            if(f.exists())
                oos = new MyObjectOutputStream(new FileOutputStream(f,true));
            else{
                oos = new ObjectOutputStream(new FileOutputStream(f));
            }

            oos.writeObject(p);
            oos.close();
        }
        catch(IOException ex)
        {
            System.out.println("File not found in writer");
        }
    }
    public static ArrayList<Store> readFromStoreItemsFile(){
        ArrayList<Store>list = new ArrayList<Store>();
        ObjectInputStream  ois;
        try
        {
            ois = new ObjectInputStream(new FileInputStream("StoreItems.ser"));
            while(true)
            {
                Store e = (Store) ois.readObject();
                list.add(e);
            }

        }
        catch(ClassNotFoundException e1)
        {
            System.out.println("ClassNotFoundException");
        }
        catch(EOFException e2)
        {
            return list;
        }
        catch(IOException ex)
        {
            System.out.println("File not found in reader");
        }
        return list;
    }
    public static void deleteExpiredProducts(int year){
        ArrayList<Store>list = Store.readFromStoreItemsFile();
        for (int i = 0;i<list.size();i++) {

            for (int j = 0;j<list.get(i).getAllProducts().length;j++) {
                if (list.get(i).getAllProducts()[j] != null) {
                    if (list.get(i).getAllProducts()[j] instanceof BakeryItem) {
                        BakeryItem temp_1 = (BakeryItem) list.get(i).getAllProducts()[j];
                        if (temp_1.getEXPDate().getYear() < year) {
                            list.remove(i);
                            break;
                        }
                    } else if (list.get(i).getAllProducts()[j] instanceof OtherItems) {
                        OtherItems temp_2 = (OtherItems) list.get(i).getAllProducts()[j];
                        if (temp_2.getEXPDate().getYear() < year) {
                            list.remove(i);
                            break;
                        }
                    }
                }
            }
        }
        try {
            File f = new File("StoreItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
    public static void updatePriceOfProduct(Product p,int price){
        ArrayList<Store>list = Store.readFromStoreItemsFile();
        for (int i = 0;i<list.size();i++) {
            for (int j = 0;j<list.get(i).getAllProducts().length;j++) {
                if (list.get(i).getAllProducts()[j] != null) {
                    if (p instanceof BakeryItem && list.get(i).getAllProducts()[j]instanceof BakeryItem) {
                        BakeryItem temp_1 = (BakeryItem) p;
                        if (temp_1.isEqual(list.get(i).getAllProducts()[j])) {
                            list.get(i).getAllProducts()[j].setPrice(price);
                            break;
                        }
                    } else if (p instanceof OtherItems && list.get(i).getAllProducts()[j]instanceof OtherItems) {
                        OtherItems temp_2 = (OtherItems) p;
                        if (temp_2.isEqual(list.get(i).getAllProducts()[j])){
                            list.get(i).getAllProducts()[j].setPrice(price);
                            break;
                        }
                    }
                }
            }
        }
        try {
            File f = new File("StoreItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
    public static void addCustomerItem(Product p) {
        ArrayList<Store> list = Store.readFromStoreItemsFile();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getAllProductsCount() >=list.get(i).getAllProducts().length) {
                System.out.println("STORE IS EMPTY");
                return;
            }
            for (int j = 0; j < list.get(i).getAllProducts().length; j++) {
                if (list.get(i).allProducts[j] == null) {
                    list.get(i).allProducts[j] = p;
                    list.get(i).setAllProductsCount(list.get(i).getAllProductsCount() + 1);
                    break;
                }
            }

        }
        try {
            File f = new File("StoreItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i< list.size(); i++){
                oos.writeObject(list.get(i));
            }
        }
        catch (IOException e){
            System.out.println("File not found in writer");
        }
    }
    public static void DeleteStoreItem(Product p) {
        ArrayList<Store> list = Store.readFromStoreItemsFile();
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getAllProductsCount() == 0) {
                System.out.println("CART IS EMPTY ");
                return;
            }
            for (int j = 0; j < list.get(i).getAllProducts().length; j++) {
                if (list.get(i).getAllProducts()[j].isEqual(p)) {
                    for (int k = j; k < list.get(i).getAllProducts().length - 1; k++) {
                        list.get(i).getAllProducts()[k] = list.get(i).getAllProducts()[k + 1];
                    }
                    list.get(i).setAllProductsCount(list.get(i).getAllProductsCount() - 1);
                    break;
                }
            }

        }
        try {
            File f = new File("StoreItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
}

