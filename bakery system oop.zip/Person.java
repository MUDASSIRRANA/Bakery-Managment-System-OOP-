import java.io.Serializable;

public class Person implements Serializable{
    protected String name;
    protected String CNIC;

    Person(String n,String c){
        this.name = n;
        this.CNIC = c;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }
    public String toString(){
        return ("Name : "+this.getName()+"\nCustomer CNIC : "+this.getCNIC());
    }
    public void display(){
        System.out.println(this.toString());
    }


    public boolean isEqual(Person temp) {
        return (this.getName().equals(temp.getName()) && this.getCNIC().equals(temp.getCNIC()));
    }
}

