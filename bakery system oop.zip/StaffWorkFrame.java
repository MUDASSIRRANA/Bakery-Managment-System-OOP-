import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StaffWorkFrame extends JFrame {
    JButton b1,b2,b3,b4,b5;

    StaffWorkFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(6,2,10,10));
        b1 = new JButton("Add New Bakery Item");
        b2 = new JButton("Add New Other Item");
        b3 = new JButton("Delete Expire Items");
        b4 = new JButton("Update price");
        b5 = new JButton("Cancel");
        add(b1);add(b2);add(b3);add(b4);add(b5);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
        b3.addActionListener(a);
        b4.addActionListener(a);
        b5.addActionListener(a);

    }
    public class MyActionListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Add New Bakery Item")){
                BakeryItemFrame b = new BakeryItemFrame();
            }
            if (e.getActionCommand().equals("Add New Other Item")){
                OtherItemsFrame o = new OtherItemsFrame();
            }
            if (e.getActionCommand().equals("Delete Expire Items")){
                ExpireItemsFrame ex = new ExpireItemsFrame();
            }
            if (e.getActionCommand().equals("Update Price")){
                UpdatePriceFrame u = new UpdatePriceFrame();
            }
            if (e.getActionCommand().equals("Cancel")){
                dispose();
            }
        }
    }
}

