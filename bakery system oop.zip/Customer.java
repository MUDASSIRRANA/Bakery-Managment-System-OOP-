import java.io.Serializable;

public class Customer extends Person implements Serializable {

    Customer(String n, String c) {
        super(n, c);
    }
    public void display(){
        System.out.println(super.toString());
    }
    public boolean isEqual(Customer temp){
        return (super.isEqual(temp));
    }


}

