import java.io.*;
import java.util.ArrayList;

public class OtherItems extends Product implements Serializable,Equal {
    private String company;

    OtherItems(PDate m, PDate e, String n,int p,String c) {
        super(m, e, n,p);
        this.company = c;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
    public String toString(){
        return (super.toString()+"\nCompany : "+this.getCompany());
    }
    public void display(){
        System.out.println(this.toString());
    }
    @Override
    public boolean isEqual(Object o){
        OtherItems temp = (OtherItems) o;
        return (super.isEqual(o) && this.company.equals(temp.getCompany()));
    }
    public static void writeOtherItemsToFile(OtherItems p){
        try
        {
            File f = new File("OtherItems.ser");

            ObjectOutputStream oos;
            if(f.exists())
                oos = new MyObjectOutputStream(new FileOutputStream(f,true));
            else{
                oos = new ObjectOutputStream(new FileOutputStream(f));
            }

            oos.writeObject(p);
            oos.close();
        }
        catch(IOException ex)
        {
            System.out.println("File not found in writer");
        }
    }
    public static ArrayList<OtherItems> readFromOtherItemsFile(){
        ArrayList<OtherItems>list = new ArrayList<OtherItems>();
        ObjectInputStream  ois;
        try
        {
            ois = new ObjectInputStream(new FileInputStream("OtherItems.ser"));
            while(true)
            {
                OtherItems e = (OtherItems) ois.readObject();
                list.add(e);
            }

        }
        catch(ClassNotFoundException e1)
        {
            System.out.println("ClassNotFoundException");
        }
        catch(EOFException e2)
        {
            return list;
        }
        catch(IOException ex)
        {
            System.out.println("File not found in reader");
        }
        return list;
    }
    public static void deleteExpireItems(int year) {
        ArrayList<OtherItems> list = OtherItems.readFromOtherItemsFile();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getEXPDate().getYear() == year){
                list.remove(i);
                break;
            }
        }
        try {
            File f = new File("OtherItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
    public static void updatePriceOfItem(String name,int price){
        ArrayList<OtherItems>list = OtherItems.readFromOtherItemsFile();
        for (int i = 0; i< list.size() ; i++){
            if (list.get(i).getName().equals(name)){
                list.get(i).setPrice(price);
                break;
            }
        }
        try {
            File f = new File("OtherItems.ser");
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) {
                oos.writeObject(list.get(i));
            }
        } catch (IOException e) {
            System.out.println("File not found in writer");
        }
    }
}

