import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class BakeryItemFrame extends JFrame {

    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9;
    JButton b1,b2;

    BakeryItemFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(6,2,10,10));
        l1 = new JLabel("Manufacture Date");
        l2 = new JLabel("Day");
        l3 = new JLabel("Month");
        l4 = new JLabel("Year");
        l5 = new JLabel("Expiry Date");
        l6 = new JLabel("Day");
        l7 = new JLabel("Month");
        l8 = new JLabel("Year");
        l9 = new JLabel("Name");
        l10 = new JLabel("price");
        l11 = new JLabel("Type");
        t1 = new JTextField(10);
        t2 = new JTextField(10);
        t3 = new JTextField(10);
        t4 = new JTextField(10);
        t5 = new JTextField(10);
        t6 = new JTextField(10);
        t7 = new JTextField(20);
        t8 = new JTextField(20);
        t9 = new JTextField(20);
        b1= new JButton("ADD");
        b2 = new JButton("CANCEL");
        add(l1);add(l2);add(l3);add(l4);add(new JPanel());add(t1);add(t2);add(t3);add(l5);add(l6);add(l7);add(l8);add(new JPanel());
        add(t4);add(t5);add(t6);add(l9);add(t7);add(l10);add(t8);add(l11);add(t9);add(b1);add(b2);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
    }
    public class MyActionListner implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("ADD")){
                int d1 = Integer.parseInt(t1.getText());int m1 = Integer.parseInt(t2.getText());int y1 = Integer.parseInt(t3.getText());
                int d2 = Integer.parseInt(t4.getText());int m2 = Integer.parseInt(t5.getText());int y2 = Integer.parseInt(t6.getText());
                String n = t7.getText(); int p = Integer.parseInt(t8.getText());String t = t9.getText();
                PDate m = new PDate(d1,m1,y1);
                PDate ex = new PDate(d2,m2,y2);
                BakeryItem b = new BakeryItem(m,ex,n,p,t);
                BakeryItem.writeBakeryItemsToFile(b);
                JOptionPane.showMessageDialog(null,"ITEM ADDED");
            }
            if (e.getActionCommand().equals("CANCEL")){
                dispose();
            }
        }
    }
}

