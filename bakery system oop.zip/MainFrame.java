import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    JButton b1,b2,b3;

    MainFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(6,2,10,10));
        b1 = new JButton("Staff Work");
        b2 = new JButton("Customer Order");
        b3 = new JButton("Cancel");
        add(b1);add(b2);add(b3);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
        b3.addActionListener(a);
    }
    public class MyActionListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Staff Work")){
                StaffWorkFrame a = new StaffWorkFrame();
            }
            if (e.getActionCommand().equals("Customer Order")){
                OrderFrame o = new OrderFrame();
            }
            if (e.getActionCommand().equals("Cancel")){
                dispose();
            }
        }
    }
}

