public class runner {
    public static void main(String[] args) {
        MainFrame f=new MainFrame();
    }
}
