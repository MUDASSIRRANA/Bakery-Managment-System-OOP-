import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExpireItemsFrame extends JFrame {
    JLabel l1;
    JTextField t1;
    JButton b1,b2;

    ExpireItemsFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(6,2,10,10));
        l1 = new JLabel("Enter Today's Year");
        t1 = new JTextField(20);
        b1 = new JButton("Delete Items");
        b2 = new JButton("Cancel");
        add(l1);add(t1);add(b1);add(b2);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
    }
    public class MyActionListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Delete Items")){
                int y = Integer.parseInt(t1.getText());
                BakeryItem.deleteExpireItems(y);
                OtherItems.deleteExpireItems(y);
                JOptionPane.showMessageDialog(null,"All Expired Items are Deleted");
            }
            if (e.getActionCommand().equals("Cancel")){
                dispose();
            }
        }
    }
}

