import java.io.Serializable;

public class Product implements Serializable,Equal {
    protected PDate MGFDate;
    private PDate EXPDate;
    protected String name;
    protected int price;
    Product(PDate m,PDate e,String n,int p){
        this.MGFDate = m;
        this.EXPDate = e;
        this.name = n;
        this.price = p;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public PDate getMGFDate() {
        return MGFDate;
    }

    public void setMGFDate(PDate MGFDate) {
        this.MGFDate = MGFDate;
    }

    public PDate getEXPDate() {
        return EXPDate;
    }

    public void setEXPDate(PDate EXPDate) {
        this.EXPDate = EXPDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString(){
        return ("Name : "+this.getName()+"\nPrice : "+this.getPrice()+"\nManufacture Date : "+this.MGFDate.toString()+"\nExpiry Date : "+this.EXPDate.toString());
    }
    public void display(){
        System.out.println(this.toString());
    }


    @Override
    public boolean isEqual(Object o) {
        Product temp = (Product) o;
        return  (this.getEXPDate().isEqual(temp.getEXPDate() ) && this.getMGFDate().isEqual(temp.getMGFDate()) && this.price == temp.getPrice() && this.name.equals(temp.getName()));
    }
}

