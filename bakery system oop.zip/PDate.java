import java.io.Serializable;

public class PDate implements Serializable,Equal {
    private int day;
    private int month;
    private int year;

    PDate(int d,int m,int y){
        if (d<0 || d>31){
            this.day = 1;
        }
        if (m<0 || m>12){
            this.month = 1;
        }
        this.day = d;
        this.month = m;
        this.year = y;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public String toString(){
        return (this.day+" : "+this.month+" : "+this.year);
    }


    @Override
    public boolean isEqual(Object o) {
        PDate temp = (PDate) o;
        return (this.day == temp.getDay() && this.month == temp.getMonth() && this.year == temp.getYear() );

    }
}

