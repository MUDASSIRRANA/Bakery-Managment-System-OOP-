public interface Equal {
    public boolean isEqual(Object o);


}

