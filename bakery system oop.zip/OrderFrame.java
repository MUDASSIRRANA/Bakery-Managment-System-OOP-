
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class OrderFrame extends JFrame {
    JLabel l1,l2;
    JTextField t1,t2,t3;
    JButton b1,b2,b3,b4;

    OrderFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(6,2,10,10));
        l1 = new JLabel("Name");
        l2 = new JLabel("CNIC");
        t1 = new JTextField(20);
        t2 = new JTextField(20);
        t3 = new JTextField(20);
        b1 = new JButton("Register Customer");
        b2 = new JButton("Add This Product");
        b3 = new JButton("Generate Bill");
        b4 = new JButton("Cancel order");
        add(l1);add(l2);add(t1);add(t2);add(t3);add(b1);add(b2);add(b3);add(b4);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
        b3.addActionListener(a);
        b4.addActionListener(a);
    }
    public class MyActionListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Register Customer")){
                String n = t1.getText();
                String c= t2.getText();
                Customer c1 = new Customer(n,c);
                Order o = new Order(c1);
                Order.writeServeToFile(o);
                JOptionPane.showMessageDialog(null,"New Customer Added");
            }
            if (e.getActionCommand().equals("Add This Product")){
                String n = t1.getText();
                String p = t3.getText();
                ArrayList<Order>list = Order.readFromAppointmentFile();
                for (int i = 0 ;i<list.size();i++){
                    if (list.get(i).getCustomer().getName().equals(n)){
                        if (checkProduct(p) != null){
                            if (checkProduct(p)instanceof BakeryItem){
                                Order.addCustomerItem(list.get(i).getCustomer(),checkProduct(p));
                                break;
                            } else if (checkProduct(p)instanceof OtherItems) {
                                Order.addCustomerItem(list.get(i).getCustomer(),checkProduct(p));
                                break;
                            }

                        }
                    }
                }
                JOptionPane.showMessageDialog(null,"Product Added");
            }
            if (e.getActionCommand().equals("Generate Bill")){
                String n = t1.getText();
                ArrayList<Order>list = Order.readFromAppointmentFile();
                for (int i = 0;i<list.size();i++){
                    if (list.get(i).getCustomer().getName().equals(n)){
                        JOptionPane.showMessageDialog(null,list.get(i).getSpentMoney());
                        break;
                    }
                }
            }
            if (e.getActionCommand().equals("Cancel order")){
                dispose();
            }
        }
        public Product checkProduct(String n){
            ArrayList<BakeryItem>list1 = BakeryItem.readFromBakeryItemsFile();
            ArrayList<OtherItems>list2 = OtherItems.readFromOtherItemsFile();
            for (int i = 0;i < list1.size();i++){
                if (list1.get(i).getName().equals(n)){
                    return list1.get(i);
                }
            }
            for (int i = 0;i<list2.size();i++){
                if (list2.get(i).getName().equals(n)){
                    return list2.get(i);
                }
            }
            return null;
        }
    }
}
