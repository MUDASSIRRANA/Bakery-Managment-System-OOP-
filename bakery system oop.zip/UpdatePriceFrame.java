import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class UpdatePriceFrame extends JFrame {
    JLabel l1,l2;
    JTextField t1,t2;
    JButton b1,b2;

    UpdatePriceFrame(){
        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new GridLayout(2,2));
        l1 = new JLabel("Enter Name Of Product");
        l2 = new JLabel("Enter new Price");
        t1 = new JTextField(20);
        t2 = new JTextField(20);
        b1 = new JButton("Update Price");
        b2 = new JButton("Cancel");
        add(l1);add(l2);add(t1);add(t2);add(b1);add(b2);
        MyActionListner a = new MyActionListner();
        b1.addActionListener(a);
        b2.addActionListener(a);
    }
    public class MyActionListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Update Price")){
                String n = t1.getText();
                int p = Integer.parseInt(t2.getText());
                if (checkProduct(n)!=null){
                    if (checkProduct(n)instanceof BakeryItem){
                        BakeryItem.updatePriceOfItem(n,p);
                    } else if (checkProduct(n)instanceof OtherItems) {
                        OtherItems.updatePriceOfItem(n,p);
                    }
                    JOptionPane.showMessageDialog(null,"Price Update");
                }
                JOptionPane.showMessageDialog(null,"Item not found");
            }
            if (e.getActionCommand().equals("Cancel")){
                dispose();
            }
        }
        public Product checkProduct(String n){
            ArrayList<BakeryItem> list1 = BakeryItem.readFromBakeryItemsFile();
            ArrayList<OtherItems>list2 = OtherItems.readFromOtherItemsFile();
            for (int i = 0;i < list1.size();i++){
                if (list1.get(i).getName().equals(n)){
                    return list1.get(i);
                }
            }
            for (int i = 0;i<list2.size();i++){
                if (list2.get(i).getName().equals(n)){
                    return list2.get(i);
                }
            }
            return null;
        }
    }
}

